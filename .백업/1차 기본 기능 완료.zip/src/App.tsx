import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';

// Context Providers
import { MemoProvider } from './contexts/MemoContext';
import { ImageProvider } from './contexts/ImageContext';
import { TemplateProvider } from './contexts/TemplateContext';

// 레이아웃 컴포넌트
import Header from './components/layout/Header';

// 메인 페이지들
import HomePage from './pages/HomePage';
import MemoWritePage from './pages/MemoWritePage';
import MemoDetailPage from './pages/MemoDetailPage';
import TemplateManagePage from './pages/TemplateManagePage';

// 테스트 페이지들
import ComponentTest from './pages/ComponentTest';
import ServiceTest from './pages/ServiceTest';
import ImageUtilsTest from './pages/ImageUtilsTest';
import MemoCRUDTest from './pages/MemoCRUDTest';
import ImageAttachmentTest from './pages/ImageAttachmentTest';
import TemplateManagementTest from './pages/TemplateManagementTest';
import PerformanceTest from './pages/PerformanceTest';

// 레이아웃 컴포넌트
const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main>{children}</main>
    </div>
  );
};

function App() {
  return (
    <Router>
      <MemoProvider>
        <ImageProvider>
          <TemplateProvider>
            <div className="App">
              <Routes>
                {/* 메인 페이지들 */}
                <Route path="/" element={<Layout><HomePage /></Layout>} />
                <Route path="/write" element={<Layout><MemoWritePage /></Layout>} />
                <Route path="/memo/:id" element={<MemoDetailPage />} />
                <Route path="/templates" element={<Layout><TemplateManagePage /></Layout>} />
                
                {/* 테스트 페이지들 */}
                <Route path="/test" element={<ComponentTest />} />
                <Route path="/service-test" element={<ServiceTest />} />
                <Route path="/image-utils-test" element={<ImageUtilsTest />} />
                <Route path="/memo-crud-test" element={<MemoCRUDTest />} />
                <Route path="/image-attachment-test" element={<ImageAttachmentTest />} />
                <Route path="/template-management-test" element={<TemplateManagementTest />} />
                <Route path="/performance-test" element={<PerformanceTest />} />
              </Routes>
            </div>
          </TemplateProvider>
        </ImageProvider>
      </MemoProvider>
    </Router>
  );
}

export default App;
