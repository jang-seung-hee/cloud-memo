import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Button, Icon, BottomTabBar } from '../ui';
import type { IconName } from '../ui/Icon';

interface HeaderProps {
  className?: string;
}

const Header: React.FC<HeaderProps> = ({ className = '' }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  // 메뉴 토글
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  // 메뉴 닫기
  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  // 탭 설정
  const tabs = [
    {
      id: 'memos',
      label: '메모 목록',
      icon: 'FileText' as IconName,
      isActive: location.pathname === '/' || location.pathname === '/write'
    },
    {
      id: 'templates',
      label: '상용구 관리',
      icon: 'Copy' as IconName,
      isActive: location.pathname === '/templates'
    }
  ];

  // 탭 변경 처리
  const handleTabChange = (tabId: string) => {
    if (tabId === 'memos') {
      navigate('/');
    } else if (tabId === 'templates') {
      navigate('/templates');
    }
  };

  return (
    <>
      <header className={`bg-white shadow-sm border-b border-gray-200 ${className}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* 로고 */}
            <div className="flex items-center">
              <Link to="/" className="flex items-center space-x-2" onClick={closeMenu}>
                <div className="w-8 h-8 bg-gradient-to-br from-primary-start to-primary-end rounded-lg flex items-center justify-center">
                  <Icon name="FileText" size={20} className="text-white" />
                </div>
                <span className="text-xl font-bold text-gray-900">Cloud Memo</span>
              </Link>
            </div>

            {/* 데스크톱 네비게이션 */}
            <nav className="hidden md:flex items-center space-x-8">
              {/* 네비게이션 링크 제거됨 */}
            </nav>

            {/* 액션 버튼들 */}
            <div className="hidden md:flex items-center space-x-4">
              {/* 새 메모 버튼 제거됨 */}
            </div>

            {/* 모바일 메뉴 버튼 */}
            <div className="md:hidden">
              <Button
                onClick={toggleMenu}
                variant="ghost"
                size="sm"
                className="p-2"
              >
                <Icon name={isMenuOpen ? "X" : "Settings"} size={20} />
              </Button>
            </div>
          </div>

          {/* 모바일 메뉴 */}
          {isMenuOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 bg-white border-t border-gray-200">
                {/* 모바일 메뉴 링크 제거됨 */}
              </div>
            </div>
          )}
        </div>
      </header>

      {/* 하단 고정 탭 - 모든 화면에서 표시 */}
      <BottomTabBar
        tabs={tabs}
        onTabChange={handleTabChange}
      />
    </>
  );
};

export default Header; 