import React from 'react';
import { Icon } from './index';
import type { IconName } from './Icon';

export interface TabItem {
  id: string;
  label: string;
  icon: IconName;
  isActive?: boolean;
}

export interface BottomTabBarProps {
  tabs: TabItem[];
  onTabChange: (tabId: string) => void;
  className?: string;
}

const BottomTabBar: React.FC<BottomTabBarProps> = ({
  tabs,
  onTabChange,
  className = ''
}) => {
  return (
    <div className={`fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50 ${className}`}>
      <div className="flex items-center justify-around">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`flex flex-col items-center justify-center py-3 px-4 flex-1 transition-colors duration-200 ${
              tab.isActive
                ? 'text-primary-start bg-blue-50'
                : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
            }`}
          >
            <Icon 
              name={tab.icon} 
              size={20} 
              className={tab.isActive ? 'text-primary-start' : 'text-gray-500'}
            />
            <span className={`text-xs mt-1 font-medium ${
              tab.isActive ? 'text-primary-start' : 'text-gray-500'
            }`}>
              {tab.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default BottomTabBar; 